@include('admin.sidebar')

<section class="home-section">
    @include('admin.navbar')
    <div class="home-content">
        <div class="container mt-4">
        @if(session('message'))
        <h6 class="alert alert-success">
            {{ session('message') }}
        </h6>
        @endif
        <form action="{{ route('admin.product') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="categoryId">Category</label>
                    <select name="categoryId" id="categoryId" class="form-control">
                        @foreach ($categories as $category)
                            <option value="{{ $category->categoryId }}">{{ $category->categoryName }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group col-md-6">
                    <label for="subCategoryId">Sub Category</label>
                    <select name="subCategoryId" id="subCategoryId" class="form-control">
                        <!-- Options will be dynamically populated using JavaScript -->
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="subcategoryName">Product Name</label>
                    <input type="text" class="form-control" id="productName" name="productName" maxlength="5000">
                </div>
                <div class="form-group col-md-6">
                    <label for="subcategoryName">Product Price</label>
                    <input type="text" class="form-control" id="productPrice" name="productPrice" maxlength="5000">
                </div>
            </div>


            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="subcategoryName">Product Sale Price</label>
                    <input type="text" class="form-control" id="productSalePrice" name="productSalePrice" maxlength="5000">
                </div>
                <div class="form-group col-md-4">
                    <label for="subcategoryName">Product Description</label>
                    <input type="text" class="form-control" id="productDescription" name="productDescription" maxlength="5000">
                </div>
                <div class="form-group col-md-4">
                    <label for="subcategoryName">Product Type</label>
                    <select name="productType" id="productType" class="form-control">
                        <option value="latest">latest</option>
                        <option value="Popular">Popular</option>
                        <option value="Trending">Trending</option>
                    </select>
                </div>
            </div>


            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="subcategoryName">Product Rating</label>
                    <input type="text" class="form-control" id="productRating" name="productRating" maxlength="5000">
                </div>
                
            <!-- Image Upload Section (You can add it as needed) -->
                <div class="form-group col-md-6">
                    <label for="image">Images</label>
                    <input type="file" class="form-control-file" id="image" name="image[]" multiple>
                </div>
            </div>

          


            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        </div>
    </div>
</section>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
        sidebar.classList.toggle("active");
        if (sidebar.classList.contains("active")) {
            sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
        } else
            sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    }
</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function () {
    $('#categoryId').change(function () {
        var categoryId = $(this).val();

        // Send an AJAX request to fetch subcategories based on the selected category
        $.ajax({
            url: '/admin/getSubCategories', // Replace with your actual route URL
            method: 'POST',
            data: {
                categoryId: categoryId,
                _token: '{{ csrf_token() }}'
            },
            success: function (data) {
                // Clear the existing options
                $('#subCategoryId').empty();

                // Populate the "Sub Category" select with the retrieved data
                data.forEach(function (subCategory) {
                    $('#subCategoryId').append(
                        '<option value="' + subCategory.subCategoryId + '">' + subCategory.subCategoryName + '</option>'
                    );
                });
            }
        });
    });
});
</script>



</body>

</html>